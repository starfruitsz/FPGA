# 嵌入式FPGA代码

Anlogic SparkRoad-V（EG4S20BG256）数字示波器 + ADRC 控制板 —— **可综合、可仿真的完整代码工程**。
只有代码和必要工程文件，不含文档、PDF、比特流与综合中间产物。

```
嵌入式FPGA代码/
├── rtl/      56 个 .v  RTL 源码（保持原有层次：vga/hal|abs|app、adc/...）
├── sim/      31 个 .v  testbench + run_all.ps1（Icarus 一键回归）
├── build/    23 个 .tcl 构建脚本 + 17 个 .al 工程 + eg4/ 约束（.adc/.sdc）
└── tools/    gen_adda_pins.py / gen_adc_pins.py / check_ports.py / lint.sh / bpf_model.py
```

## 1. 跑仿真回归（不需要 FPGA、不需要 TD 授权）

前提：Icarus Verilog。**PATH 必须同时包含 `bin` 和 `lib`**（只加 bin 会让 vvp 段错误）：

```bash
export PATH="<oss-cad-suite>/bin:<oss-cad-suite>/lib:$PATH"
cd 嵌入式FPGA代码
pwsh -File sim/run_all.ps1 -IverilogPath <oss-cad-suite>/bin
```

期望：`TOTAL: PASS=24 FAIL=0 SKIP=0`

## 2. 静态检查门禁

```bash
bash tools/lint.sh                      # 6 个定点运算模块必须零告警
python tools/check_ports.py             # 模块/例化端口一致性（49 模块 / 76 例化）
python tools/bpf_model.py               # 48Hz 带通位精确参考模型（返回 0 = PASS）
```

## 3. 综合（需要安路 TD 5.6.5 + 授权）

**必须在本 `build/` 目录下执行**（脚本内的 `add_files` 都是相对路径）：

```bash
cd 嵌入式FPGA代码/build
rm -rf scope_local36.al scope_local36_Runs      # TD 不允许复用工程名
<TD>/bin/td_commands_prompt.exe -nogui < make_scope_local36.tcl
```

产物：`scope_local36_Runs/best_result/scope_local36.bit`（638,952 B）

> ⚠️ 本目录名含中文。多数 Windows 工具链能处理，但安路 TD 对非 ASCII 路径未做保证。
> 若 `create_project` 报路径错误，把整个文件夹改名为纯英文（如 `fpga_code`）再跑。

## 4. 烧写

```bash
printf 'download -bit <abs>/scope_local36.bit -mode jtag_burst -spd 4 -cable 0\nexit\n' \
  | <TD>/bin/td_commands_prompt.exe -nogui          # SRAM，约 25 s
```

固化 Flash 用 `-mode program_spi -chip EG4S20BG256 -flashsize 32 -spd 1`（约 270 s，**必须 -spd 1**）。

## 5. 引脚约束怎么改

约束文件是 `build/eg4/SparkRoad.adc`，由 CSV 生成：

```bash
python tools/gen_adda_pins.py    # rtl/adc/pins/adda_pins.csv -> build/eg4/SparkRoad.adc 的 AD/DA 段
python tools/gen_adc_pins.py     # rtl/adc/pins/board_pins.csv -> build/eg4/SparkRoad.adc
```

## 6. 代码入口

| 文件 | 作用 |
|---|---|
| `rtl/sparkroad_scope_top.v` | 板级顶层（ADC 并口、ADRC、数码管、开关） |
| `rtl/sparkroad_scope_pll.v` | 实际综合用的顶层（PLL 25.2MHz / 60Hz） |
| `rtl/vga/vga_scope_top.v` | 示波器主体：采集/触发/图层/菜单/双缓冲 |
| `rtl/vga/app/scope_app.v` | 按键与开关状态机（缩放、菜单、串口配置） |
| `rtl/vga/app/bpf_ctrl.v` | 48Hz 算法带通（ADRC 输入，SW13 控制） |
| `rtl/eso.v` | ADRC 扩展状态观测器 + 控制律 |

## 7. 已知状态

- 仿真回归：**24/24 PASS**；lint 门禁：**6 模块零告警**
- 板上/Flash 当前固件：**scope_local33**（本包未含比特流）
- 待办：ADRC 参数整定需硬件在环
